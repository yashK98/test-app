# Local ML Drift Monitoring MVP

A local starter application for monitoring text and prediction drift for your sentiment classifier. It uses FastAPI, SQLite, Streamlit, Pandas and Evidently. No embeddings are generated.

## What it does

- Loads a reference CSV containing `client_message` and `sentiment`.
- Receives prediction events from your existing inference service at `POST /predictions`.
- Stores events in local SQLite.
- Compares the reference and recent production data with Evidently's `DataDriftPreset`.
- Saves HTML and JSON reports under `reports/`.
- Provides a small Streamlit dashboard to trigger checks and view run history.

## Important baseline note

This MVP compares the reference dataset's labelled `sentiment` distribution with production `predicted_sentiment` distribution. This is a useful initial signal, but it is not a perfectly like-for-like prediction drift comparison. For the rigorous version, run your deployed sentiment model over the reference messages once, save those model predictions as a `reference_predictions.csv`, and use those predictions as the reference prediction column. The text-content comparison can use the original reference messages immediately.

No drift tool can prove prediction correctness without actual labels. Keep a small human-reviewed sample process if possible.

## 1. Prepare the reference CSV

Copy your CSV to:

`data/reference/sentiment_reference.csv`

It must contain these exact columns:

- `client_message`
- `sentiment`

Extra columns are ignored. If your actual file uses different column names, rename them or adjust `REFERENCE_PATH` and the column mapping in `app/drift.py`.

The screenshot shared in the conversation is not the CSV file itself. The original CSV needs to be copied here locally.

## 2. Install (Windows PowerShell)

Use Python 3.11 or 3.12.

```powershell
cd ml-drift-monitor
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, run this once in that terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 3. Start the API

Terminal 1:

```powershell
cd ml-drift-monitor
.\.venv\Scripts\Activate.ps1
uvicorn app.api:app --reload --port 8000
```

API docs: http://127.0.0.1:8000/docs

## 4. Start the dashboard

Terminal 2:

```powershell
cd ml-drift-monitor
.\.venv\Scripts\Activate.ps1
streamlit run dashboard.py
```

Dashboard: http://localhost:8501

## 5. Connect your inference service

After your model predicts sentiment, send the prediction to the collector. Example Python code:

```python
import requests

requests.post(
    "http://127.0.0.1:8000/predictions",
    json={
        "client_message": message,
        "predicted_sentiment": prediction,
        "confidence": confidence,
        "model_version": "sentiment-v1"
    },
    timeout=2
)
```

Do this asynchronously or through a queue in production so monitoring storage cannot slow down inference. Do not log sensitive message data unless your data policy permits it; consider masking and retention controls.

You can also test the collector in Swagger at `/docs` using `POST /predictions`.

## 6. Run a drift check

For a quick local test, first ingest at least 100 predictions (or lower `min_rows` in the dashboard). Then click **Run drift check**.

Or call the API:

```powershell
Invoke-RestMethod -Method Post "http://127.0.0.1:8000/drift/run?hours=24&min_rows=100"
```

Evidently reports are saved in `reports/`. The dashboard lets you download the HTML report.

## 7. Test the system before trusting it

- First send messages similar to your reference data and run a check.
- Then send a deliberately different batch (e.g. messages from a different language/domain) and run another check.
- Confirm that the report identifies which columns changed.
- Do not treat one drift alert as a reason to retrain automatically.

## Current MVP limitations

- SQLite is for local development, not a multi-instance production deployment.
- The scheduler is not included yet; trigger checks manually from the dashboard/API. Add a Kubernetes CronJob or scheduler after validating the workflow.
- Prediction confidence is collected but not yet included in the Evidently report. This is a next iteration.
- The reference-vs-production sentiment comparison must be upgraded to use reference model predictions for a strict prediction drift comparison.
- This MVP has no authentication. Keep it bound to localhost; do not expose it to a network as-is.
