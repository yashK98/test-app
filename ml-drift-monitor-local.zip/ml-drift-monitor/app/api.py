from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from . import storage
from .drift import REFERENCE_PATH, run_drift

app = FastAPI(title="ML Drift Monitoring API", version="0.1.0")


class PredictionIn(BaseModel):
    client_message: str = Field(min_length=1)
    predicted_sentiment: str = Field(min_length=1)
    confidence: float | None = Field(default=None, ge=0, le=1)
    model_version: str | None = None
    prediction_timestamp: str | None = None


@app.on_event("startup")
def startup():
    storage.init_db()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predictions")
def ingest_prediction(item: PredictionIn):
    ts = storage.save_prediction(item.client_message, item.predicted_sentiment, item.confidence,
                                 item.model_version, item.prediction_timestamp)
    return {"stored": True, "prediction_timestamp": ts}


@app.post("/reference/upload")
def upload_reference():
    raise HTTPException(status_code=501, detail="Use the setup script to place your CSV at data/reference/sentiment_reference.csv for this MVP.")


@app.post("/drift/run")
def trigger_drift(hours: int = 24, min_rows: int = 100):
    try:
        return run_drift(hours=hours, min_rows=min_rows)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/drift/runs")
def drift_runs():
    return storage.get_runs()


@app.get("/predictions/count")
def prediction_count():
    return {"count": len(storage.get_predictions(limit=200000))}
