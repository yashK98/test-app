import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
from evidently import Dataset, DataDefinition, Report
from evidently.presets import DataDriftPreset

from . import storage

REFERENCE_PATH = Path(os.getenv("REFERENCE_PATH", "./data/reference/sentiment_reference.csv"))
REPORT_DIR = Path(os.getenv("REPORT_DIR", "./reports"))
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def _find_drift_flags(value):
    flags = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"drift_detected", "dataset_drift"} and isinstance(child, bool):
                flags.append(child)
            else:
                flags.extend(_find_drift_flags(child))
    elif isinstance(value, list):
        for child in value:
            flags.extend(_find_drift_flags(child))
    return flags


def run_drift(hours=24, min_rows=100):
    started = datetime.now(timezone.utc)
    now = started.isoformat()
    ref = pd.read_csv(REFERENCE_PATH)
    if "client_message" not in ref.columns or "sentiment" not in ref.columns:
        raise ValueError("Reference CSV must contain client_message and sentiment columns.")
    ref = ref[["client_message", "sentiment"]].copy()
    ref["client_message"] = ref["client_message"].fillna("").astype(str)
    ref["sentiment"] = ref["sentiment"].fillna("UNKNOWN").astype(str)
    # The reference sentiment column is the historical labelled distribution.
    # For a strict prediction-vs-prediction comparison, supply reference predictions
    # from the deployed model in a future extension.

    since_dt = started - timedelta(hours=hours)
    rows = storage.get_predictions(since=since_dt.isoformat(), limit=200000)
    cur = pd.DataFrame(rows)
    if len(cur) < min_rows:
        raise ValueError(f"Only {len(cur)} production predictions found; at least {min_rows} are required.")
    cur = cur.rename(columns={"predicted_sentiment": "sentiment"})
    cur = cur[["client_message", "sentiment"]].copy()
    cur["client_message"] = cur["client_message"].fillna("").astype(str)
    cur["sentiment"] = cur["sentiment"].fillna("UNKNOWN").astype(str)

    schema = DataDefinition(text_columns=["client_message"], categorical_columns=["sentiment"])
    reference_dataset = Dataset.from_pandas(ref, data_definition=schema)
    current_dataset = Dataset.from_pandas(cur, data_definition=schema)
    report = Report([DataDriftPreset(columns=["client_message", "sentiment"], include_tests=True)])
    snapshot = report.run(current_dataset, reference_dataset)
    report_id = started.strftime("%Y%m%d_%H%M%S")
    html_path = REPORT_DIR / f"sentiment_drift_{report_id}.html"
    json_path = REPORT_DIR / f"sentiment_drift_{report_id}.json"
    snapshot.save_html(str(html_path))
    raw_json = snapshot.json()
    json_path.write_text(raw_json, encoding="utf-8")
    parsed = json.loads(raw_json)
    flags = _find_drift_flags(parsed)
    status = "DRIFT_DETECTED" if any(flags) else ("NO_DRIFT_DETECTED" if flags else "REVIEW_REPORT")
    run_id = storage.save_run(
        started_at=now,
        window_start=since_dt.isoformat(),
        window_end=now,
        reference_rows=len(ref),
        current_rows=len(cur),
        status=status,
        report_html=str(html_path),
        report_json=str(json_path),
        error=None,
    )
    return {"run_id": run_id, "status": status, "reference_rows": len(ref), "current_rows": len(cur),
            "report_html": str(html_path), "report_json": str(json_path)}
