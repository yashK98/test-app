import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(os.getenv("DATABASE_PATH", "./data/monitoring.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_message TEXT NOT NULL,
            predicted_sentiment TEXT NOT NULL,
            confidence REAL,
            model_version TEXT,
            prediction_timestamp TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS drift_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT NOT NULL,
            window_start TEXT,
            window_end TEXT,
            reference_rows INTEGER NOT NULL,
            current_rows INTEGER NOT NULL,
            status TEXT NOT NULL,
            report_html TEXT,
            report_json TEXT,
            error TEXT
        )""")


def save_prediction(message, sentiment, confidence=None, model_version=None, timestamp=None):
    timestamp = timestamp or datetime.now(timezone.utc).isoformat()
    with connect() as conn:
        conn.execute(
            "INSERT INTO predictions(client_message,predicted_sentiment,confidence,model_version,prediction_timestamp) VALUES(?,?,?,?,?)",
            (message, sentiment, confidence, model_version, timestamp),
        )
    return timestamp


def get_predictions(since=None, limit=100000):
    query = "SELECT * FROM predictions"
    params = []
    if since:
        query += " WHERE prediction_timestamp >= ?"
        params.append(since)
    query += " ORDER BY prediction_timestamp DESC LIMIT ?"
    params.append(limit)
    with connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def save_run(**kwargs):
    with connect() as conn:
        cur = conn.execute("""INSERT INTO drift_runs
            (started_at,window_start,window_end,reference_rows,current_rows,status,report_html,report_json,error)
            VALUES(:started_at,:window_start,:window_end,:reference_rows,:current_rows,:status,:report_html,:report_json,:error)""", kwargs)
        return cur.lastrowid


def get_runs(limit=30):
    with connect() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM drift_runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
