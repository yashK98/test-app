import os
from pathlib import Path

import pandas as pd
import requests
import streamlit as st

API = os.getenv("DRIFT_API_URL", "http://127.0.0.1:8000")
st.set_page_config(page_title="ML Drift Monitor", layout="wide")
st.title("ML Drift Monitoring")
st.caption("Sentiment Analysis · Local MVP")

try:
    health = requests.get(f"{API}/health", timeout=3).json()
    count = requests.get(f"{API}/predictions/count", timeout=3).json()["count"]
    runs = requests.get(f"{API}/drift/runs", timeout=3).json()
except Exception:
    st.error("Cannot reach the Drift API. Start the API using the instructions in README.md.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("API status", health.get("status", "unknown"))
c2.metric("Stored predictions", count)
c3.metric("Monitoring runs", len(runs))

st.subheader("Run drift detection")
hours = st.selectbox("Production lookback window", [24, 48, 72, 168], index=0, format_func=lambda x: f"Last {x} hours")
min_rows = st.number_input("Minimum production records", min_value=10, max_value=100000, value=100, step=10)
if st.button("Run drift check", type="primary"):
    with st.spinner("Comparing reference and production data with Evidently..."):
        response = requests.post(f"{API}/drift/run", params={"hours": hours, "min_rows": min_rows}, timeout=600)
    if response.ok:
        result = response.json()
        st.success(f"Run #{result['run_id']} completed: {result['status']}")
        st.json(result)
        st.rerun()
    else:
        st.error(response.json().get("detail", response.text))

st.subheader("Monitoring history")
if runs:
    view = pd.DataFrame(runs)
    st.dataframe(view[["id", "started_at", "status", "reference_rows", "current_rows", "error"]], use_container_width=True)
    selected = st.selectbox("Open report for run", view["id"].tolist())
    record = next(r for r in runs if r["id"] == selected)
    report_path = Path(record["report_html"]) if record.get("report_html") else None
    if report_path and report_path.exists():
        st.download_button("Download Evidently HTML report", report_path.read_bytes(), file_name=report_path.name, mime="text/html")
else:
    st.info("No monitoring runs yet. Add production predictions and run your first check.")

st.caption("A drift signal is an investigation trigger, not proof that model accuracy has fallen.")
